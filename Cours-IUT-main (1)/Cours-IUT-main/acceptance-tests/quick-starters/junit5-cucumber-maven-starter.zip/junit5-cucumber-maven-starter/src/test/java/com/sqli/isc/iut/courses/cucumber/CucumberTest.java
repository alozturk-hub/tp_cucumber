package com.sqli.isc.iut.courses.cucumber;

import io.cucumber.junit.platform.engine.Cucumber;

@Cucumber
public class CucumberTest {
	
    // See:
    // https://github.com/cucumber/cucumber-jvm/issues/1149
    // https://github.com/cucumber/cucumber-jvm/tree/master/junit-platform-engine
}
